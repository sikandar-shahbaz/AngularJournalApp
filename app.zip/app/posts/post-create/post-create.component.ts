import { Component } from "@angular/core";
import { NgForm } from "@angular/forms";

import { PostsService } from "../posts.service";

@Component({
  selector: "app-post-create",
  templateUrl: "./post-create.component.html",
  styleUrls: ["./post-create.component.css"]
})
export class PostCreateComponent {

  constructor(public postsService: PostsService) {}

  onAddPost(form: NgForm) {
    if (form.invalid) {
      return;
    }
    let formattedDate = this.convertDate(form.value.title)
    this.postsService.addPost(formattedDate, form.value.content);
    form.resetForm();
  }

  convertDate(date: Date){
    let newDate = new Date(date);

    let monthNames = [
      "January", "February", "March",
      "April", "May", "June", "July",
      "August", "September", "October",
      "November", "December"
    ];
  
    let day = newDate.getDate();
    let monthIndex = newDate.getMonth();
    let year = newDate.getFullYear();
  
    return day + ' ' + monthNames[monthIndex] + ' ' + year;
  }
}
